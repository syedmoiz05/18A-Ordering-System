/* The Printable interface declares method to print a summary
   Any class using this interface has to have a printSummary() method.
*/
public interface Printable {
    void printSummary();
}
